import { Injectable } from '@angular/core';
import { Http, Response } from "@angular/http";
import { Observable } from "rxjs/Observable";
import { Character } from "../model/character"
import "rxjs/add/operator/toPromise";

@Injectable()
export class CharacterService {

  private swapiUrl: string = "https://swapi.co/api/people/?search=";

  constructor(private http: Http) {}


  getCharacterRequest(strName, page): Promise<Object[]> {
  	return new Promise((resolve, reject) =>{
  		return this.http.get(this.swapiUrl+strName+"&page="+page)
  		.toPromise()
  		.then((response) => {
  			resolve(response.json()["results"]);
  		})
  	})
  }

  getCharacterDetails(strName: string): Promise<Character> {
  	return new Promise((resolve, reject) => {
  		this.http.get(this.swapiUrl+strName)
  		.toPromise()
  		.then((response) => {
  			resolve(this.parseJson(response.json()["results"][0]));
  		})
  		.catch((error) => {
  			reject(error)
  		});
  	});
  }

  parseJson(response): Character {
  	let character = new Character();
  	
    character.name = response.name;
  	character.gender = response.gender;
  	character.birthDate = response.birth_year;
  	character.height = response.height;
  	character.mass = response.mass;
  	character.hair_color = response.hair_color;
  	character.skin_color = response.skin_color;
  	character.eye_color = response.eye_color;
  	character.homeworld = response.homeworld;
  	character.films = response.films;
  	character.species = response.species;
  	character.starships = response.starships;

  	return character;
  }

}
