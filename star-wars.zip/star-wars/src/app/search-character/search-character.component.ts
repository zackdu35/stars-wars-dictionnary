import { Component, OnInit } from '@angular/core';
import { CharacterService } from 'app/services/character.service';

@Component({
  selector: 'app-search-character',
  templateUrl: './search-character.component.html',
  styleUrls: ['./search-character.component.css']
})
export class SearchCharacterComponent {

  public nameSearch: string = "";
  public characters: Object[];
  public page: number = 1;


  constructor(private characterService : CharacterService) { 
  		this.filterCharacter();
  }

  filterCharacter(){
  	this.characterService.getCharacterRequest(this.nameSearch, this.page)
  	.then((list) => {
  		this.characters = list;
  	})
  	.catch((error) => {
  		console.log("error: ", error);	
  	})
  }

  clickedPrevious(){
  	this.page = this.page == 1 ? 1 : --this.page; 
  	this.filterCharacter();
  }

  clickedNext(){
  	this.page++;
  	this.filterCharacter();
  }

}
