export class Character {

  public name: string;
  public gender: string;
  public birthDate: string;
  public height: string;
  public mass: string;
  public hair_color: string;
  public skin_color: string;
  public eye_color: string;
  public homeworld: string;
  public films: string;
  public species: string;
  public starships: string;

}