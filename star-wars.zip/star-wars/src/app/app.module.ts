import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';

import { CharacterService } from './services/character.service';

import { AppComponent } from './app.component';
import { SearchCharacterComponent } from './search-character/search-character.component';
import { DetailsComponent } from './details/details.component';
import { RouterModule, Routes } from '@angular/router';

const approutes: Routes = [
  {path: "home", component: SearchCharacterComponent},
  {path: "detail/:name", component: DetailsComponent},
  {path: "**", redirectTo:"/home", pathMatch: "full"}
];

@NgModule({
  declarations: [
    AppComponent,
    SearchCharacterComponent,
    DetailsComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    RouterModule.forRoot(approutes)
  ],
  providers: [CharacterService],
  bootstrap: [AppComponent]
})
export class AppModule { }
