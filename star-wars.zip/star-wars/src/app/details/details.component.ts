import { Component, OnInit } from '@angular/core';
import { Character } from "../model/character";
import { ActivatedRoute } from "@angular/router";
import { CharacterService } from 'app/services/character.service';

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
})
export class DetailsComponent implements OnInit {
  
  private sub: any;
  public name: string = "";
  public character: Character = new Character();

  constructor(private route: ActivatedRoute, private characterService: CharacterService) { }

  ngOnInit() {
  	this.sub = this.route.params.subscribe( params => {
  		this.name = params["name"];
  		this.displayDetail();
  	})
  }

  displayDetail(){
  	this.characterService.getCharacterDetails(this.name)
  	.then((character) => {
  		this.character = character;
  	})
  	.catch((error) => {
  		console.log("error: ", error);	
  	})
  }


}
